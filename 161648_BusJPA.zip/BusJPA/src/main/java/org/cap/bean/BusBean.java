package org.cap.bean;



import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Table(name="buspassrequest")
@Entity
public class BusBean {
	@Id
	@GeneratedValue
	private Integer reqId;
	private String emp_id;
	private String firstName;
	private String lastName;
	private String gen;
	private String address;
	private LocalDate doj;
	private String emailId;
	private String location;
	private String pickupLoc;
	private String designation;
	private LocalTime pickupTime;
	
	private String status="Pending";
	@OneToOne
	@JoinColumn
	private RouteMapBean route;	
	public BusBean() {
		super();
	}
	public BusBean(String emp_id, String firstName, String lastName, String gen, String address, LocalDate doj,
			String emailId, String location, String pickupLoc, String designation, LocalTime pickupTime, String status) {
		super();
		this.emp_id = emp_id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gen = gen;
		this.address = address;
		this.doj = doj;
		this.emailId = emailId;
		this.location = location;
		this.pickupLoc = pickupLoc;
		this.designation = designation;
		this.pickupTime = pickupTime;
		this.status = status;
	}
	public BusBean(Integer reqId, String emp_id, String firstName, String lastName, String gen, String address,
			LocalDate doj, String emailId, String location, String pickupLoc, String designation, LocalTime pickupTime,
			String status) {
		super();
		this.reqId = reqId;
		this.emp_id = emp_id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gen = gen;
		this.address = address;
		this.doj = doj;
		this.emailId = emailId;
		this.location = location;
		this.pickupLoc = pickupLoc;
		this.designation = designation;
		this.pickupTime = pickupTime;
		this.status = status;
	}
	public Integer getReqId() {
		return reqId;
	}
	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}
	public String getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(String emp_id) {
		this.emp_id = emp_id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getGen() {
		return gen;
	}
	public void setGen(String gen) {
		this.gen = gen;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public LocalDate getDoj() {
		return doj;
	}
	public void setDoj(LocalDate doj) {
		this.doj = doj;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getPickupLoc() {
		return pickupLoc;
	}
	public void setPickupLoc(String pickupLoc) {
		this.pickupLoc = pickupLoc;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public LocalTime getPickupTime() {
		return pickupTime;
	}
	public void setPickupTime(LocalTime pickupTime) {
		this.pickupTime = pickupTime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
			
	public RouteMapBean getRoute() {
		return route;
	}

	public void setRoute(RouteMapBean route) {
		this.route = route;
	}
	@Override
	public String toString() {
		return "BusBean [reqId=" + reqId + ", emp_id=" + emp_id + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", gen=" + gen + ", address=" + address + ", doj=" + doj + ", emailId=" + emailId + ", location="
				+ location + ", pickupLoc=" + pickupLoc + ", designation=" + designation + ", pickupTime=" + pickupTime
				+ ", status=" + status + ", route=" + route + "]";
	}
}