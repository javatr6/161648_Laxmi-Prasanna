package com.capgemini.service;

import com.capgemini.dao.ILoginDAO;
import com.capgemini.dao.LoginDAO;
import com.capgemini.model.LoginBean;

public class LoginServiceImpl implements ILoginService {
	ILoginDAO loginDAO = new LoginDAO();
	@Override
	public boolean checkUser(LoginBean loginBean) {
		return loginDAO.checkUser(loginBean);
	}

}
