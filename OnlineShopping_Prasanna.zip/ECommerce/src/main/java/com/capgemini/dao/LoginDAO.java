package com.capgemini.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.model.LoginBean;




public class LoginDAO implements ILoginDAO {

	@Override
	public boolean checkUser(LoginBean loginBean) {
		String sql="select username,password from details where username=? and password=?";
		boolean flag = false;
		try(PreparedStatement ps =getSQLConnection().prepareStatement(sql);){

			ps.setString(1, loginBean.getUsername());
			ps.setString(2, loginBean.getPassword());
			ResultSet rs =ps.executeQuery();
			/*if(rs.next()) {
				return true;

			}*/
			while(rs.next()) {
				
				if(rs.getString("username").equals(loginBean.getUsername())&&rs.getString("password").equals(loginBean.getPassword())) {
				flag=true;	
				return flag;
				}
				flag=false;
				}
				

		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;


	}
	private Connection getSQLConnection()
	{
		Connection con=null;
		try{


			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/capdb","root","India123");
			return con;
		}catch(SQLException e)
		{
			e.printStackTrace();
		}catch(Exception e1) {
			e1.printStackTrace();
		}

		return con;
	}
}

