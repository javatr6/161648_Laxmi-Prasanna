package com.cpg.manytomany;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class MainClass {
	public static void main(String[] args) {
		 
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo");
				
				EntityManager entityManager = emf.createEntityManager();
				
				entityManager.getTransaction().begin();
				
				
		 
        Events java=new Events();
		java.setEventId("101_JAVA");
		java.setEventName("JAVA");
		java.setDateOfJoining(LocalDate.now());
		
		Events oracle=new Events();
		oracle.setEventId("221_ORACLE");
		oracle.setEventName("ORACLE");
		oracle.setDateOfJoining(LocalDate.now());

		Events dotnet=new Events();
		dotnet.setEventId("333_DOTNET");
		dotnet.setEventName("DOTNET");
		dotnet.setDateOfJoining(LocalDate.now());
		
		Delegates tom=new Delegates(1,"tom");
		Delegates tom1=new Delegates(12,"jack");
		Delegates tom2=new Delegates(19,"tom1");
		Delegates tom3=new Delegates(20,"tom2");
		Delegates tom4=new Delegates(3,"tom3");

		tom.getEvents().add(java);
		tom.getEvents().add(oracle);
		tom.getEvents().add(dotnet);

		tom1.getEvents().add(java);
		tom1.getEvents().add(oracle);
		tom1.getEvents().add(dotnet);
		
		entityManager.persist(tom);
		entityManager.persist(tom1);
		entityManager.persist(tom2);
		entityManager.persist(tom3);
		entityManager.persist(tom4);
		
		entityManager.persist(java);
		entityManager.persist(oracle);
		entityManager.persist(dotnet);
		entityManager.getTransaction().commit();
		

	}

}