package com.cpg.controller;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		Company cg=new Company("cg");
		Company tcs=new Company("tcs");
		
		Employee employee=new Employee(1001,"tinku",cg);
		employee.setDateOfJoining(LocalDate.now());
		
		Employee employee1=new Employee(1002,"chitti",tcs);
		employee1.setDateOfJoining(LocalDate.now());
		
		Employee employee2=new Employee(1003,"milky",cg);
		employee2.setDateOfJoining(LocalDate.now());
		
		Employee employee3=new Employee(1004,"nithi",tcs);
		employee3.setDateOfJoining(LocalDate.now());
		
		entityManager.persist(cg);
		entityManager.persist(tcs);
		
		entityManager.persist(employee);
		entityManager.persist(employee1);
		entityManager.persist(employee2);
		entityManager.persist(employee3);
		transaction.commit();
		entityManager.close();
		
	}

}
