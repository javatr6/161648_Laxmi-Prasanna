package com.cpg.model;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {
	
	public static void main(String[] args) {
		
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo");
	 EntityManager entityManager = emf.createEntityManager();
	 EntityTransaction transaction = entityManager.getTransaction();
	 
	 transaction.begin();
	 Customer tom = new Customer("tom","jerry",3500);
	 Address address = new Address(4001,"MIPL",tom);
	 
	 
	 Customer jack = new Customer("jack","jill",5500);
	 Address address1 = new Address(4003,"MIPL",jack);
	 
	 entityManager.persist(tom);
	 entityManager.persist(address);
	 
	 entityManager.persist(jack);
	 entityManager.persist(address1);
	 
	 transaction.commit();
	 entityManager.close();
	}
} 
 
